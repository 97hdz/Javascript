var Artist = "Tame Impala";
var Album = "Currents";
var ReleaseYear = 2015;
var Genre = "Synth Pop";
var KP = "Kevin Parker";
var Min = 6.03;
var EngineeredBy = KP;
var Producedby = KP;

console.log("My favorite song is : "+Artist);
console.log("Album : "+Album);
console.log("Year : "+ReleaseYear);
console.log("Genre : "+Genre);
console.log("Produced by : "+KP);
console.log("Engineered by : "+KP);
console.log("Minutes : "+Min);
